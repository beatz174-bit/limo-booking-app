


function RideHistoryPage() {

    return <h1>Ride History Page</h1>;
}



export default RideHistoryPage
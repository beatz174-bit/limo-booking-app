




function BookingPage() {

    return <h1>Booking Page</h1>;
}


export default BookingPage



function RideHistoryPage() {

    return ("Ride History Page")
}



export default RideHistoryPage
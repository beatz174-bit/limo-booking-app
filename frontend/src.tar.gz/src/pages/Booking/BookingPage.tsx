




function BookingPage() {

    return ("Booking Page")
}


export default BookingPage
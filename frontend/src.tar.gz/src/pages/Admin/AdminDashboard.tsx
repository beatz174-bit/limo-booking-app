

function AdminDashboard() {

    return ("Admin Dashboard")
}

export default AdminDashboard
// src/pages/HomePage.tsx
export default function HomePage() {
  return <div className="p-4 text-xl">Welcome to Limo Booking Service</div>;
}
